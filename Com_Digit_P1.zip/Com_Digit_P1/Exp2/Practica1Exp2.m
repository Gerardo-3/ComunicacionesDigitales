th=PressureAndVelocity.Time_s_;
h=PressureAndVelocity.Altitude_m_;
p=PressureAndVelocity.Pressure_hPa_;

tv=PressureAndVelocity.Time_velocity__s_;
yv=PressureAndVelocity.Velocity_m_s_;

ta=Acceleration.Time_s_;
A=Acceleration.Acceleration_m_s__;


f = figure;
subplot(4,1,1);
plot(th,h);
xlabel('Time [s]');
ylabel('h [m]');
grid on

subplot(4,1,2);
plot(tv,yv);
xlabel('Time [s]');
ylabel('Vel.Vert.[m/s]');
grid on

subplot(4,1,3);
plot(ta,A);
xlabel('Time [s]');
ylabel('Acc.Z [m/s^2]');
grid on

subplot(4,1,4);
plot(th,p);
xlabel('Time [s]');
ylabel('P [hPa]');
grid on

saveas(f, 'GraficaExp2.png'); 
