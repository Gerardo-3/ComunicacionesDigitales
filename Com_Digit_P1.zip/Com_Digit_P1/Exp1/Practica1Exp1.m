t = RawData.Time_s_ ;
x = RawData.LinearAccelerationX_m_s_2_;
y = RawData.LinearAccelerationY_m_s_2_;
z = RawData.LinearAccelerationZ_m_s_2_;
aabs = RawData.AbsoluteAcceleration_m_s_2_;

g = figure;
subplot(4,1,1);
plot(t,x,'Color','#AF172E');
xlabel('Time [s]');
ylabel('Acc.X [m/s^2]');
grid on

subplot(4,1,2);
plot(t,y);
xlabel('Time [s]');
ylabel('Acc.Y [m/s^2]');
grid on

subplot(4,1,3);
plot(t,z,'Color','#0DA50D');
xlabel('Time [s]');
ylabel('Acc.Z [m/s^2]');
grid on

subplot(4,1,4);
plot(t,aabs,'Color','#D16A12');
xlabel('Time [s]');
ylabel('Abs.Acc.[m/s^2]');
grid on

saveas(g, 'GraficaExp1.png'); 