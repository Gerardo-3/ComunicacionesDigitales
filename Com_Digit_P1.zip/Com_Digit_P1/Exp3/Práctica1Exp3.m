Distancia = EchoLocation.Distance_cm_;
A = EchoLocation.Crosscorrelation_a_u__;

Delay = Time.Delay_s_;
ADelay = Time.Crosscorrelation_a_u__;

Velocidad = SpeedOfSound.SpeedOfSound_m_s_;
AVel = SpeedOfSound.Crosscorrelation_a_u__;

h = figure;
subplot(3,1,1);
plot(Delay,ADelay);
xlabel("Retraso [s]");
ylabel("Amplitud [u.arb]");
grid on;

subplot(3,1,2);
plot(D,A);
xlabel("Distancia [cm]");
ylabel("Amplitud [u.arb]");
grid on;

subplot(3,1,3);
plot(Velocidad,AVel);
xlabel("Velocidad sonido [m/s]");
ylabel("Amplitud [u.arb]");
grid on;

saveas(h,'GraficaExp3.png');